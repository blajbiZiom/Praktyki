<script>
/* import TaskList from './components/TaskList.vue'; */
import { ref } from 'vue';

export default {
  setup() {
    const tasksToDo = ref([]);
    const tasksDone = ref([]);
    const newTask = ref('');
    const welcomeText = ref(['Dodaj nowe zadanie!']);

    const updateWelcomeText = () => {
      if (tasksToDo.value.length === 0) {
        welcomeText.value = 'Dodaj nowe zadanie!';
      } else {
        welcomeText.value = [];
      }
    };

    const addTask = () => {
      if (newTask.value.trim() !== '') {
        tasksToDo.value.push({ text: newTask.value, done: false });
        newTask.value = '';
        updateWelcomeText();
      }
    };

    const TaskStatus = (task) => {
      if (task.done) {
        tasksToDo.value.push({ ...task, done: false });
        tasksDone.value.splice(tasksDone.value.indexOf(task), 1);
      } else {
        tasksDone.value.push({ ...task, done: true });
        tasksToDo.value.splice(tasksToDo.value.indexOf(task), 1);
      }
      updateWelcomeText();
    };

    const deleteTask = (task) => {
      tasksToDo.value.splice(tasksToDo.value.indexOf(task), 1);
      updateWelcomeText();
    };

    updateWelcomeText();

    return {
      tasksToDo,
      tasksDone,
      newTask,
      addTask,
      TaskStatus,
      deleteTask,
      welcomeText,
    };
  },
};
</script>

<template>
  <div class="container">
    <h1>To Do App</h1>
    <div class="main-content">
      <div class="left-panel">
        <div class="input-container">
          <input
            type="text"
            placeholder="Write your task here..."
            v-model="newTask"
            class="task-input"
          />
          <button @click="addTask" class="btn">Add Task</button>
        </div>
        <div class="task-list">
          <h2>To Do Things:</h2>
          <p v-if="welcomeText.length > 0">{{ welcomeText }}</p>
          <ul>
            <li v-for="task in tasksToDo" :key="task.text" class="task-item">
              <button class="btn" @click="deleteTask(task)">Delete</button>
              <input
                type="checkbox"
                @click="TaskStatus(task)"
                v-model="task.done"
              />
              <span>{{ task.text }}</span>
            </li>
          </ul>
        </div>
      </div>
      <div class="right-panel">
        <h2>Tasks You Have Done:</h2>
        <ul>
          <li v-for="task in tasksDone" :key="task.text" class="task-item">
            <input
              type="checkbox"
              @click="TaskStatus(task)"
              v-model="task.done"
            />
            <span>{{ task.text }}</span>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<style scoped>
.container {
  max-width: 1000px;
  margin: 50px auto;
  padding: 20px;
  background: #f8f9fa;
  border-radius: 10px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  text-align: center;
}

h1 {
  font-size: 2rem;
  color: #343a40;
  margin-bottom: 30px;
}

.main-content {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 20px;
}

.left-panel {
  flex: 2;
  background: white;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.right-panel {
  flex: 1;
  background: #ffffff;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.input-container {
  display: flex;
  justify-content: center;
  gap: 10px;
  margin-bottom: 20px;
}

.task-input {
  flex: 1;
  padding: 10px;
  font-size: 1rem;
  border: 1px solid #ced4da;
  border-radius: 5px;
}

.btn {
  padding: 10px 20px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
  font-size: 1rem;
  cursor: pointer;
}

.btn:hover {
  background-color: #0056b3;
}

.task-list ul,
.right-panel ul {
  list-style-type: none;
  padding: 0;
  margin: 0;
}

.task-item {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 10px;
  font-size: 1rem;
}
</style>

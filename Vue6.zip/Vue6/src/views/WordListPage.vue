<template>
    <div class="word-list" style="margin-bottom: 200px;">
      <h1>Word List</h1>
      <ul v-if="words.length">
        <li v-for="(item, index) in words" :key="index">
          <strong>{{ item.word }}</strong>: {{ item.translation }}
        </li>
      </ul>
      <p v-else>No words added yet!</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'WordListPage',
    data() {
      return {
        words: []
      }
    },
    mounted() {
      const storedWords = JSON.parse(localStorage.getItem('words'));
      if (storedWords) {
        this.words = storedWords;
      }
    }
  }
  </script>
  
  <style>
  ul {
    list-style-type: none;
    padding: 0;
  }
  li {
    padding: 5px 0;
    color:goldenrod;
  font-weight: 600;
  font-size: large;
  }
  h2, h1{
  color: antiquewhite;
  
}
p{
  color:goldenrod;
  font-weight: 600;
  font-size: large;
}
  </style>
  
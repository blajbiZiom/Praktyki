<template>
  <div class="home">
    <h1>Language Learning App</h1>
    <p>Welcome! Choose an action:</p>
    <router-link to="/add-word">
      <button>Add New Word</button>
    </router-link>
    <router-link to="/learn">
      <button>Learn Words</button>
    </router-link>
    <router-link to="/quiz">
      <button>Take a Quiz</button>
    </router-link>
    <router-link to="/progress">
      <button>View Progress</button>
    </router-link>
    <router-link to="/word-list">
      <button>Your Words</button>
    </router-link>
  </div>
</template>

<script>
export default {
  name: 'Home'
}
</script>

<style>

.home{
  margin-bottom: 200px;
}
button {
  margin: 10px;
  padding: 10px 20px;
  font-size: 16px;
  cursor: pointer;
  transition: 0.3s;
  background-color: antiquewhite;
}



h2, h1{
  color: antiquewhite;
  transition: 0.5s;
  cursor: default;
}
h2,h1:hover{
  color:brown;
  font-size: 65px;
}
p{
  color:goldenrod;
  font-weight: 600;
  font-size: large;
}

button:hover{
  background-color:darkorange;
  border: 1px solid chocolate;
  padding: 15px 23px;
}
</style>

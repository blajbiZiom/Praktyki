<template>
    <div class="quiz-page" style="margin-bottom: 200px;">
      <h1>Quiz</h1>
      <div v-if="words.length">
        <p><strong>Translate:</strong> {{ currentWord.word }}</p>
        <input type="text" v-model="userAnswer" placeholder="Your answer" />
        <button @click="checkAnswer">Check Answer</button>
        <p v-if="feedback">{{ feedback }}</p>
      </div>
      <p v-else>No words available for the quiz!</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'QuizPage',
    data() {
      return {
        words: [],
        currentIndex: 0,
        userAnswer: '',
        feedback: '',
        correctAnswers: JSON.parse(localStorage.getItem('correctAnswers')) || 0,
        quizzesCompleted: JSON.parse(localStorage.getItem('quizzesCompleted')) || 0
      };
    },
    computed: {
      currentWord() {
        return this.words[this.currentIndex];
      }
    },
    methods: {
      checkAnswer() {
        if (this.userAnswer.toLowerCase() === this.currentWord.translation.toLowerCase()) {
          this.feedback = "Correct!";
          this.correctAnswers++;
        } else {
          this.feedback = `Wrong! Correct answer: ${this.currentWord.translation}`;
        }
        this.saveProgress();
        this.userAnswer = '';
        this.nextWord();
      },
      nextWord() {
        if (this.currentIndex < this.words.length - 1) {
          this.currentIndex++;
        } else {
          alert("Quiz completed!");
          this.resetQuiz();
        }
      },
      saveProgress() {
        this.quizzesCompleted++;
        localStorage.setItem('quizzesCompleted', JSON.stringify(this.quizzesCompleted));
        localStorage.setItem('correctAnswers', JSON.stringify(this.correctAnswers));
      },
      resetQuiz() {
        this.currentIndex = 0;
        this.feedback = '';
      }
    },
    mounted() {
      const storedWords = JSON.parse(localStorage.getItem('words'));
      if (storedWords) {
        this.words = storedWords;
      }
    }
  };
  </script>
  
  
  <style>
  input {
    margin: 10px 0;
    padding: 8px;
  }
  button {
    padding: 10px;
    margin: 10px;
  }
  h2, h1{
  color: antiquewhite;
}
p{
  color:goldenrod;
  font-weight: 600;
  font-size: large;
}
  </style>
  
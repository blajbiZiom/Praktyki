<template>
    <div class="add-word" style="margin-bottom: 200px;">
      <h1>Add New Word</h1>
      <form @submit.prevent="addWord">
        <label for="word">Word:</label>
        <input type="text" id="word" v-model="word" required />
  
        <label for="translation">Translation:</label>
        <input type="text" id="translation" v-model="translation" required />
  
        <button type="submit">Add Word</button>
      </form>
    </div>
  </template>
  
  <script>
  export default {
    name: 'AddWordPage',
    data() {
      return {
        word: '',
        translation: ''
      }
    },
    methods: {
      addWord() {
        const words = JSON.parse(localStorage.getItem('words')) || [];
        words.push({ word: this.word, translation: this.translation });
        localStorage.setItem('words', JSON.stringify(words));
        this.word = '';
        this.translation = '';
        alert('Word added successfully!');
      }
    }
  }
  </script>
  
  <style>
  form {
    display: flex;
    flex-direction: column;
    width: 300px;
    margin: auto;
  }
  input, button {
    margin: 10px 0;
    transition: 0.2s;
  }
  input:hover{
    padding: 10px 20px;
  }
  h2, h1{
  color: antiquewhite;
}
p, label{
  color:goldenrod;
  font-weight: 600;
  font-size: large;
}
  </style>
  
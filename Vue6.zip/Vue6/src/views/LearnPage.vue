<template>
    <div class="learn-page" style="margin-bottom: 200px;">
      <h1>Learn Words</h1>
      <div v-if="words.length">
        <p><strong>Word:</strong> {{ currentWord.word }}</p>
        <p><strong>Translation:</strong> {{ currentWord.translation }}</p>
        <button @click="nextWord">Next Word</button>
      </div>
      <p v-else>No words to learn! Add some words first.</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'LearnPage',
    data() {
      return {
        words: [],
        currentIndex: 0
      };
    },
    computed: {
      currentWord() {
        return this.words[this.currentIndex];
      }
    },
    methods: {
      nextWord() {
        if (this.currentIndex < this.words.length - 1) {
          this.currentIndex++;
        } else {
          alert("You've reached the end of the list!");
          this.currentIndex = 0;
        }
      }
    },
    mounted() {
      const storedWords = JSON.parse(localStorage.getItem('words'));
      if (storedWords) {
        this.words = storedWords;
      }
    }
  };
  </script>
  
  <style>
  button {
    margin-top: 20px;
    padding: 10px;
  }
  h2, h1{
  color: antiquewhite;
}
p{
  color:goldenrod;
  font-weight: 600;
  font-size: large;
}
  </style>
  
<template>
    <div class="progress-page" style="margin-bottom: 200px;">
      <h1>Your Progress</h1>
      <p><strong>Total Words:</strong> {{ totalWords }}</p>
      <p><strong>Quiz Attempts:</strong> {{ quizzesCompleted }}</p>
      <p><strong>Correct Answers:</strong> {{ correctAnswers }}</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'ProgressPage',
    data() {
      return {
        totalWords: 0,
        quizzesCompleted: 0,
        correctAnswers: 0
      };
    },
    mounted() {
      const storedWords = JSON.parse(localStorage.getItem('words'));
      if (storedWords) {
        this.totalWords = storedWords.length;
      }
      this.quizzesCompleted = JSON.parse(localStorage.getItem('quizzesCompleted')) || 0;
      this.correctAnswers = JSON.parse(localStorage.getItem('correctAnswers')) || 0;
    }
  };
  </script>
  
  <style>
  p {
    margin: 10px 0;
  }
  h2, h1{
  color: antiquewhite;
}
  </style>
  
import { createRouter, createWebHistory } from 'vue-router';
import Home from './views/Home.vue';
import AddWordPage from './views/AddWordPage.vue';
import LearnPage from './views/LearnPage.vue';
import QuizPage from './views/QuizPage.vue';
import ProgressPage from './views/ProgressPage.vue';
import WordListPage from './views/WordListPage.vue';

const routes = [
  { path: '/', component: Home },
  { path: '/add-word', component: AddWordPage },
  { path: '/learn', component: LearnPage },
  { path: '/quiz', component: QuizPage },
  { path: '/progress', component: ProgressPage },
  { path: '/word-list', component: WordListPage }
];

export default createRouter({
  history: createWebHistory(),
  routes
});

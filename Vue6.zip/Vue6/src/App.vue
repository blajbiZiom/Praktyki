<script>
  export default{
    name: 'App'
  }
</script>

<template>
  <div>
    <router-view />
  </div>
</template>

<style scoped>

</style>

module.exports = {
    devServer: {
      proxy: {
        '/proxy': {
          target: 'https://api.steampowered.com', // Adres API Steam
          changeOrigin: true, // Zmienia origin żądania na target
          pathRewrite: { '^/proxy': '' }, // Usuwa "/proxy" z URL
          secure: false, // Dla nieszyfrowanych połączeń
        },
      },
    },
  };
  
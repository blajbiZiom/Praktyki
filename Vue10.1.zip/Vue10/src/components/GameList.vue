<template>
  <div class="games">
    <h2>Twoje gry</h2>
 
    <div v-if="isLoading" class="loading">
      Ładowanie listy gier...
    </div>

   
    <ul v-else-if="games.length" class="game-list">
      <li v-for="game in games" :key="game.appid" class="game-item">
        <strong>{{ game.name }}</strong> - {{ formatPlaytime(game.playtime_forever) }} godzin
      </li>
    </ul>


    <p v-else class="no-games">Brak gier do wyświetlenia.</p>

    
    <p v-if="error" class="error">{{ error }}</p>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  props: {
    steamID: {
      type: String,
      required: true, 
    },
  },
  data() {
    return {
      games: [], 
      isLoading: true, 
      error: null, 
    };
  },
  methods: {
    
    formatPlaytime(playtime) {
      return (playtime / 60).toFixed(1); 
    },
    
    async fetchGames() {
      const apiKey = '6949B33AAF1813A9C27C53250D082428'; 
      const url = `http://localhost:8081/proxy/https://api.steampowered.com/IPlayerService/GetOwnedGames/v0001/`;

      try {
        const response = await axios.get(url, {
          params: {
            key: apiKey,
            steamid: this.steamID,
            include_appinfo: true,
            format: 'json',
          },
        });

        
        this.games = response.data.response.games || [];
        console.log('Pobrane gry:', this.games);
      } catch (error) {
        console.error('Błąd podczas pobierania gier:', error);
        this.error = 'Nie udało się pobrać listy gier. Spróbuj ponownie później.';
      } finally {
        this.isLoading = false; 
      }
    },
  },
  async mounted() {
    if (!this.steamID) {
      this.error = 'Nie przekazano SteamID.';
      this.isLoading = false;
      return;
    }
    await this.fetchGames();
  },
};
</script>

<style scoped>
.games {
  padding: 20px;
  background-color: #f4f4f9;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

h2 {
  font-size: 1.5rem;
  margin-bottom: 10px;
}

.loading {
  font-style: italic;
  color: #888;
}

.game-list {
  list-style: none;
  padding: 0;
}

.game-item {
  font-size: 1rem;
  margin: 5px 0;
  border-bottom: 1px solid #ddd;
  padding-bottom: 5px;
}

.no-games {
  color: #555;
  font-style: italic;
}

.error {
  color: #d9534f;
  font-weight: bold;
}
</style>

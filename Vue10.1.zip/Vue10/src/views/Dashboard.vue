<template>
  <div class="dashboard">
    <div class="main-content">
      <div class="game-list-container">
        <GameList :steamID="steamID" />
      </div>
      <div class="stats-container">
        <div class="profile-container">
          <Profile :steamID="steamID" />
        </div>
        <Stats :games="gameData" />
      </div>
    </div>
  </div>
</template>

<script>
import Profile from '@/components/Profile.vue';
import GameList from '@/components/GameList.vue';
import Stats from '@/components/Stats.vue';
import axios from 'axios';

export default {
  props: {
    steamID: {
      type: String,
      required: true, 
    },
  },
  components: {
    Profile,
    GameList,
    Stats,
  },
  data() {
    return {
      gameData: [],
      steamID: this.$route.query.steamID || '',
    };
  },
  async created() {
    if (!this.steamID) {
      alert('Steam ID nie zostało przekazane. Powrót do logowania.');
      this.$router.push('/login'); 
      return;
    }

    
    await this.fetchGameData();
  },
  methods: {
    async fetchGameData() {
      const apiKey = '6949B33AAF1813A9C27C53250D082428'; 
      try {
        const response = await axios.get(
          `http://localhost:8081/proxy/https://api.steampowered.com/IPlayerService/GetOwnedGames/v0001/`,
          {
            params: {
              key: apiKey,
              steamid: this.steamID,
              include_appinfo: true,
              format: 'json',
            },
          }
        );
        this.gameData = response.data.response.games || [];
      } catch (error) {
        console.error('Błąd podczas pobierania listy gier:', error);
      }
    },
  },
};
</script>

<style scoped>
.dashboard {
  display: flex;
  justify-content: flex-start;
  align-items: flex-start;
  height: 100vh;
  padding: 20px;
}

.profile-container {
  top: 10px;
  right: 20px;
  text-align: center;
}

.profile-container img {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  margin-bottom: 10px;
}

.main-content {
  flex: 1;
  margin-left: 20px;
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
}

.game-list-container,
.stats-container {
  width: 48%;
  padding: 20px;
  background-color: #f4f4f9;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  margin-bottom: 20px;
}

.game-list-container {
  background-color: #e7f5fe;
}

.stats-container {
  background-color: #f9e7e7;
}

h2 {
  margin-bottom: 15px;
  font-size: 1.5rem;
}
</style>

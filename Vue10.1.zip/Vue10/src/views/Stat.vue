<template>
    <div>
        <Statistics :SteamID = "SteamID" />
    </div>
</template>
<script>
import Statistics from '../components/Statistics.vue';
export default {
  props: {
    steamID: {
      type: String,
      required: true, 
    },
  },
  components:{
    Statistics,
  }
}

</script>
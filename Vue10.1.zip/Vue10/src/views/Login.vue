<template>
  <div class="login">
    <h1>Steam dashboard</h1>
    <input type="text" v-model="steamID" placeholder="Wpisz Steam ID" />
    <button @click="goToDashboard">Zaloguj</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      steamID: "", 
    };
  },
  methods: {
    goToDashboard() {
      if (this.steamID) {
        
        this.$router.push({ path: '/dashboard', query: { steamID: this.steamID } });
      } else {
        alert("Wpisz steam ID"); 
      }
    },
  },
};
</script>

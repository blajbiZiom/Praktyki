const express = require('express');
const axios = require('axios');
const cors = require('cors'); 
const app = express();

app.use(cors()); 
app.use(express.json());

app.get('/proxy/*', async (req, res) => {
  const url = req.originalUrl.replace('/proxy/', '');
  try {
    const response = await axios.get(url, { params: req.query });
    res.set('Access-Control-Allow-Origin', '*'); 
    res.json(response.data);
  } catch (error) {
    res.status(500).send(error.toString());
  }
});

app.listen(8081, () => {
  console.log('Proxy działa na http://localhost:8081');
});

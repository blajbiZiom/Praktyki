<template>
  <div class="app">
    <div class="book-finder-window">
      <h1>Wyszukiwarka książek</h1>
      <input 
        v-model="query" 
        @keyup.enter="searchBooks" 
        type="text" 
        placeholder="Wpisz tytuł lub słowa kluczowe książki ..." 
        @input="resetNothingMessage" 
      />
      <button @click="searchBooks">Szukaj</button>
      <p v-if="nothing">{{ nothing }}</p>
    </div>

    <div id="wczytywanie" v-if="loading">
      <h2>Ładowanie...</h2>
    </div>

    <div id="error" v-if="error">
      <h2>{{ error }}</h2>
    </div>

    <div class="books-found-window" v-if="books.length">
      <ul>
        <li v-for="book in books" :key="book.id">
          <h2>Tytuł: {{ book.volumeInfo.title }} | Autorzy: {{ book.volumeInfo.authors ? book.volumeInfo.authors.join(', ') : 'Nieznany autor' }}</h2>
          <h3>Description and opinions about that book: </h3>
          <p>{{ book.volumeInfo.description || 'Brak opisu' }}</p>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      query: '',
      loading: false,
      books: [],
      error: null,
      nothing: '',
    };
  },

  methods: {
    resetNothingMessage() {
      this.nothing = '';
    },

    async searchBooks() {
      this.nothing = '';
      this.error = null;
      this.books = [];

      if (!this.query.trim()) {
        this.nothing = 'Nie ma nic do wyświetlenia';
        return;
      }

      this.loading = true;

      try {
        const APIkey = 'AIzaSyBmueGOTX3g3GdYYh6odHJbI9cAavdmXjQ';
        const response = await axios.get(
          `https://www.googleapis.com/books/v1/volumes?q=${this.query}&key=${APIkey}`
        );

        this.books = response.data.items || [];

        if (!this.books.length) {
          this.nothing = 'Brak wyników dla podanego zapytania.';
        }
      } catch (error) {
        this.error = 'Coś poszło nie tak...';
        console.error(error);
      } finally {
        this.loading = false;
      }
    }
  }
};
</script>

<style scoped>
.app {
  font-family: Arial, sans-serif;
  padding: 20px;
  background-color: aliceblue;
  border-radius: 10px;
  border-style: groove;
}

.book-finder-window {
  margin-bottom: 20px;
  width: 1000px;
  height: 200px;
  margin-left: auto;
  margin-right: auto ;
}
button{
  margin-left: 10px;
  color: black;
  border: 1px solid black;
  background-color:antiquewhite;
}
button:hover{
  border: 1px solid black;
  background-color:aliceblue;
}
input{
  background-color: antiquewhite;
  border: 1px solid black;
  width: 280px
}
input:hover{
  background-color: aliceblue;
}

.books-found-window {
  margin-top: 20px;
}
.book-finder-window p{
  margin-left: auto;
  margin-right: auto;
  font-weight: bolder;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  border: 1px solid #ccc;
  border-radius: 5px;
  box-shadow: antiquewhite 2px 2px inset;
  padding: 15px;
  margin-bottom: 10px;
}
li:hover{
  transition: 0.5s;
  background-color: antiquewhite;
}

h2 {
  font-size: 18px;
  margin: 0 0 10px;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}

h1 {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

h3 {
  font-size: 16px;
  margin: 0 0 10px;
}

p {
  font-size: 14px;
}
</style>

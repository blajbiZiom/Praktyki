<script>
import jsPDF from "jspdf";
export default {
  data() {
    return {
      SelectCharacter: '', 
      imageUrl: '', 
    };
  },
  methods: {
    showCharacter() {
      
      if (this.SelectCharacter === 'Santa') {
        this.imageUrl = 'https://static.vecteezy.com/system/resources/previews/027/990/029/non_2x/ai-generative-cute-pastel-element-christmas-theme-santa-png.png'; 
        
      } else if (this.SelectCharacter === 'Reindeer') {
        this.imageUrl = 'https://static.vecteezy.com/system/resources/previews/035/282/037/non_2x/ai-generated-christmas-reindeer-cute-cartoon-character-free-png.png'; 
        
      } else if (this.SelectCharacter === 'Elf') {
        this.imageUrl = 'https://static.vecteezy.com/system/resources/previews/033/026/737/non_2x/elf-clipart-merry-christmas-and-happy-new-year-free-png.png'; 
        
      } else {
        this.imageUrl = ''; 
       
      }
    },
    exportToPDF() {
      const pdf = new jsPDF();
      pdf.html(document.querySelector(".image"), {
        callback: function (doc) {
          doc.save("swiateczna-kartka.pdf");
        },
        x: 10,
        y: 10,
      });
    },
  }
}
</script>

<template>
  <div class="app">
    <div class="left">
      <div class="characters">
        <h1>Wybierz postać: </h1>
        <select v-model="SelectCharacter">
          <option value="Santa">Święty Mikołaj</option>
          <option value="Reindeer">Renifer</option>
          <option value="Elf">Elf</option>
        </select>
        <button @click="showCharacter" type="submit">Generuj</button>
      </div>
    </div>
    <div class="right">
      <div class="image">
        <img v-if="imageUrl" :src="imageUrl" alt="Wybrana postać" />
        <p v-if="SelectCharacter === 'Santa'">Wesołych Mikołajowych Świąt!</p>
        <p v-if="SelectCharacter === 'Reindeer'">Wesołych Reniferowych Świąt!</p>
        <p v-if="SelectCharacter === 'Elf'">Wesołych Elfowych Świąt!</p>
      </div>
      <div class="export">
      <button @click="exportToPDF">Eksportuj do PDF</button>
    </div>
    </div>
  </div>
</template>

<style>

body {
  margin: 0;
  font-family: "Arial", sans-serif;
  background: #f7f7f7;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

.app {
  background: linear-gradient(to right, #ff0000, #007f00);
  border: 5px solid #fff;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  width: 80%;
  max-width: 800px;
  border-radius: 15px;
  padding: 20px;
  text-align: center;
  color: white;
  position: relative;
  height: 600px;
}

.left {
  width: 50%;
  float: left;
  text-align: center;
  padding: 10px;
}

.left h1 {
  font-size: 2.5rem;
  color: #ffe600;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
}

.left h2 {
  margin: 15px 0;
  color: #fff;
}

button {
  margin-top: 10px;
  padding: 10px 15px;
  font-size: 1rem;
  background: #ffe600;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  transition: transform 0.2s ease-in-out;
  margin-left: 10px
}

button:hover {
  transform: scale(1.1);
}


.right {
  width: 50%;
  float: right;
  text-align: center;
  padding: 10px;
}

.image img {
  max-width: 70%;
  max-height: 300px;
  border: 5px solid white;
  border-radius: 10px;
  margin-bottom: 10px;
}

p {
  font-size: 1.2rem;
  margin-top: 10px;
  color: #ffe600;
  font-weight: 600;
}


.export {
  clear: both;
  margin-top: 20px;
}

.export button {
  background: #007f00;
  color: #fff;
  padding: 10px 20px;
  font-size: 1rem;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  transition: transform 0.2s ease-in-out, background 0.2s ease-in-out;
}

.export button:hover {
  transform: scale(1.1);
  background: #004f00;
}
</style>

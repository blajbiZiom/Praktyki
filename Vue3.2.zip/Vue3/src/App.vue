<template>
  <div id="app">
    <BonusOffers />
  </div>
</template>

<script>
import BonusOffers from './components/BonusOffers.vue';

export default {
  name: 'App',
  components: {
    BonusOffers,
  },
};
</script>

<style>

body {
  font-family: Arial, sans-serif;
}
</style>

<template>
  <div class="bonus-offers">
    
    <div v-if="loading" class="loading">Ładowanie...</div>
    <div v-if="error" class="error">{{ error }}</div>
    <div v-if="bonusOffers.length > 0">
      <header class="navbar">
    <div class="navbar-container">
      
      <a href="/" class="navbar-logo">
        <img src="https://pewniaczki.pl/wp-content/themes/pewniaczki/img/logo.svg" alt="Logo" />
      </a>

      
      <nav class="navbar-links">
        <a href="https://pewniaczki.pl/ranking-bukmacherow/">Typy bukmacherskie</a>
        <a href="https://pewniaczki.pl/ranking-bukmacherow/">Bonusy i promocje</a>
        <a href="https://pewniaczki.pl/ranking-bukmacherow/">Ranking bukmacherów</a>
        <a href="https://pewniaczki.pl/ranking-bukmacherow/">Porady</a>
        <a href="https://pewniaczki.pl/ranking-bukmacherow/">Legalni bukmacherzy</a>
      </nav>

      
      <div class="navbar-social-icons">
        <a href="#" target="_blank">
          <img src="https://pewniaczki.pl/wp-content/themes/pewniaczki/img/social-fb.svg" alt="Facebook" />
        </a>
        <a href="#" target="_blank">
          <img src="https://pewniaczki.pl/wp-content/themes/pewniaczki/img/social-yt.svg" alt="YouTube" />
        </a>
        <a href="#" target="_blank">
          <img src="https://pewniaczki.pl/wp-content/themes/pewniaczki/img/social-tt.svg" alt="Twitter" />
        </a>
        <a href="#" target="_blank">
          <img src="https://pewniaczki.pl/wp-content/themes/pewniaczki/img/social-ig.svg" alt="Instagram" />
        </a>
      </div>
    </div>

    
    <div class="breadcrumbs" style="text-align: left;" >
      <a href="/"><strong>Pewniaczki.pl</strong></a>&nbsp; >&nbsp; <span>Bonusy</span>
    </div>
  </header>

  <h2 id="welcoming" style="color: black;">Bonusy powitalne u bukmacherów</h2>

      <div class="offer-card" v-for="offer in bonusOffers" :key="offer.name">
        
        <div class="images">
          <img :src="offer.image" alt="Logo {{ offer.title }}" class="offer-image" />
        </div>

        <div class="offer-content">
          <h2>{{ offer.title }}</h2>
          <p>
            Sprawdź ofertę powitalną w <a class="offer-names">{{ offer.name }}</a>.
            Przeczytaj szczegóły każdego bonusu, który oferuje bukmacher.
          </p>

          <div>
            <ul class="offer-list">
              <li v-for="(item, index) in offer.list" :key="index" v-html="item"></li>
            </ul>
          </div>
        </div>

        <div class="promo-code">
          <p>kod: <strong>{{ offer.code }}</strong></p>
          
          <a :href="offer.link" class="offer-button" target="_blank">
            Bonus {{ offer.title }} &nbsp;>
          </a>
          <a :href="offer.link" class="bonus-button" target="_blank">
            Odbierz bonus >
          </a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      loading: true,
      error: null,
      bonusOffers: [],
    };
  },
  async mounted() {
    await this.fetchBonusOffers();
  },
  methods: {
    async fetchBonusOffers() {
      console.time("Pobieranie danych");
      try {
        const response = await axios.get("https://pewniaczki.pl/wp-json/api/bonus");
        console.timeEnd("Pobieranie danych");
        console.log("Odpowiedź z API:", response.data);

        if (response.data && Array.isArray(response.data.bonuses)) {
          this.bonusOffers = response.data.bonuses.map((offer) => {
            const link = offer.name ? `https://pewniaczki.pl/bonus/${offer.name}` : null;
            return { ...offer, link };
          });
          console.log("Przetworzone oferty:", this.bonusOffers);
        } else {
          this.bonusOffers = [];
          this.error = "Brak ofert do wyświetlenia.";
        }
      } catch (err) {
        this.error = "Nie udało się pobrać danych.";
        console.error("Błąd:", err);
      } finally {
        this.loading = false;
      }
    },
  },
};
</script>

<style scoped>

.loading {
  font-size: 1.2em;
  color: #555;
}

.error {
  color: red;
  font-weight: bold;
}

.offer-card {
  display: flex;
  flex-direction: row;
  align-items: center;
  text-align: left;
  justify-content: space-between;
  border: 1px solid #ddd;
  border-radius: 5px;
  padding: 15px;
  margin-bottom: 10px;
  box-shadow: 2px 2px #edf2ef;
}

.offer-content {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.offer-content h2 {
  margin: 0 0 5px;
  text-transform: capitalize;
  font-size: 1.2em;
}

.offer-list {
  margin-top: 10px;
  padding-left: 20px;
}

.offer-list li {
  margin-bottom: 5px;
  padding-left: 30px; 
  position: relative;
  list-style-type: none;
}

.offer-list li::before {
  content: ""; 
  background-image: url("data:image/svg+xml,%3Csvg width='14' height='14' viewBox='0 0 14 14' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M6.57434 10.7114L3.68359 7.7987L5.31547 6.20138L6.57434 7.46984L11.8896 2.11414L13.5215 3.71145L6.57434 10.7114Z' fill='%2300A24C'/%3E%3Cpath d='M6.94531 14V11.745C9.50969 11.745 11.6078 9.63089 11.6078 7.047H13.8924C13.8924 10.8993 10.7686 14 6.94531 14Z' fill='%237BC193'/%3E%3Cpath d='M6.94712 14C3.12387 14 0 10.8523 0 7H2.28462C2.28462 9.58389 4.38275 11.698 6.94712 11.698V14Z' fill='%234EB270'/%3E%3Cpath d='M2.28462 7H0C0 3.14765 3.12387 0 6.94712 0C8.0195 0 9.09187 0.234899 10.071 0.751678L9.04525 2.81879C8.3925 2.48993 7.69312 2.30201 6.94712 2.30201C4.38275 2.30201 2.28462 4.41611 2.28462 7Z' fill='%2300A24C'/%3E%3C/svg%3E");
  background-size: contain; 
  background-repeat: no-repeat;
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
  width: 20px; 
  height: 20px;
}

.offer-image {
  max-width: 150px;
  height: auto;
  margin-bottom: 10px;
  margin-right: 15px;
}

.images {
  flex: 0 0 auto;
  margin-right: 15px;
}

.promo-code {
  margin-left: 30px;
  text-align: right;
}

.promo-code p {
  border: 2px dashed #10af4d;
  padding: 10px 25px;
  text-align: center;
  width: 250px;
  border-radius: 5px;
}

.bonus-button {
  display: block;
  margin-top: 10px;
  padding: 10px 25px;
  background-color: #10af4d;
  color: white;
  text-align: center;
  font-weight: bold;
  text-decoration: none;
  border-radius: 5px;
}
.offer-button {
  display: block;
  margin-top: 10px;
  padding: 10px 25px;
  background-color: #d3f0d5;
  color: #10af4d;
  text-align: center;
  font-weight: bold;
  text-decoration: none;
  border-radius: 5px;
}

.bonus-button:hover {
  background-color: #0d8c3c;
}

#welcoming {
  text-align: left;
  text-transform: uppercase;
  font-size:larger;
  font-weight: 800;
  font-family: Gill Sans, sans-serif;
  margin-top: 80px;
}
.offer-names{
  color: black;
  text-transform: uppercase;
  font-family: Gill Sans, sans-serif;
}
img{
  border-radius: 8px;
}
.navbar {
  background-color: white;
  border-bottom: 1px solid #ddd;
  padding: 10px 20px;
  position: fixed; 
  top: 0;
  z-index: 1000;
  width: 100%; 
  left: 0;
}

.navbar-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%; 
  max-width: none;
  font-family: Gill Sans, sans-serif; ; 
}


.navbar-logo {
  display: flex;
  align-items: center;
  text-decoration: none;
}

.navbar-logo img {
  height: 40px;
  margin-right: 5px;
  margin-left: 10px;
}

.navbar-logo span {
  font-weight: bold;
  font-size: 20px;
  color: #0aaf4d;
}


.navbar-links {
  display: flex;
  gap: 20px;
}

.navbar-links a {
  text-decoration: none;
  font-size: 16px;
  font-weight: 700;
  color: black;
}

.navbar-links a:hover {
  color: #10af4d;
}


.navbar-social-icons {
  display: flex;
  gap: 7px;
  margin-right: 35px;
}

.navbar-social-icons a img {
  height: 25px;
}


.breadcrumbs {
  background-color: white;
  padding: 10px 5px 20px;
  border-top: 1px solid #f4f0f0;
  border-left: 1px solid white;
  font-size: 14px;
  position: relative;
  top: 15px; 
  width: 100%; 
  left: 0;
  box-sizing: border-box; 
  margin-bottom: 5px;
  font-family: Gill Sans, sans-serif;
}

.breadcrumbs a {
  text-decoration: none;
  color: #10af4d;
  font-weight: 500;
}

.breadcrumbs span {
  font-weight: 400;
  color: black;
}
</style>

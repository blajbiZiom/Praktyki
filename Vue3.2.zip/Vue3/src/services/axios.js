
import axios from 'axios';

const api = axios.create({
  baseURL: 'https://pewniaczki.pl/wp-json/api/bonus', 
  headers: {
    'Content-Type': 'application/json',
  },
});

export default api;

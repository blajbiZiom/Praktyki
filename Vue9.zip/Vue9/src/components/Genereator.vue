<script>
export default {
  data() {
    return {
      receiver: '',
      message: '',
      closing: '',
      generatedWish: '',
      start: '',
      gender: '',
    };
  },
  methods: {
    generateWish() {
      if (this.gender === 'mężczyzna') {
        this.start = 'Najdroższy';
      } else if (this.gender === 'kobieta') {
        this.start = 'Najdroższa';
      } else {
        this.start = 'Najdroższy/a';
      }

      if (this.receiver && this.message && this.closing) {
        this.generatedWish = `${this.start} ${this.receiver}, \n\n${this.message},\n\n${this.closing}`;
      } else {
        alert('Proszę wypełnić wszystkie pola');
      }
    },
  },
};
</script>

<template>
  <div class="generator">
    <h1>Generator życzeń świątecznych</h1>
    <div class="forms">
      <label for="receiver">Odbiorca:</label>
      <input type="text" id="receiver" v-model="receiver" placeholder="Napisz imię w wołaczu!" />
      <div class="gender-selection">
        <label>
          <input type="radio" v-model="gender" value="mężczyzna" /> Mężczyzna
        </label>
        <label>
          <input type="radio" v-model="gender" value="kobieta" /> Kobieta
        </label>
      </div>
      <label for="message">Wiadomość:</label>
      <textarea id="message" v-model="message" placeholder="Wpisz tutaj swoje życzenia..."></textarea>
      <label for="closing">Zakończenie:</label>
      <input type="text" id="closing" v-model="closing" placeholder="Wpisz zakończenie..." />
      <button @click="generateWish">Wygeneruj życzenia</button>
    </div>
    <div v-if="generatedWish" class="result">
      <h2>Twoje życzenia:</h2>
      <p>{{ generatedWish }}</p>
    </div>
  </div>
</template>

<style>
.generator {
  font-family: 'Lora', serif;
  max-width: 700px;
  margin: 50px auto;
  text-align: center;
  padding: 30px;
  background: #fffaf0;
  border-radius: 20px;
  border: 1px solid #ddd;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
}

h1 {
  font-size: 2.8rem;
  color: #006400;
  margin-bottom: 20px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1.5px;
}

label {
  font-size: 1.1rem;
  color: #4b4b4b;
  font-weight: 600;
  margin-top: 15px;
  display: block;
  text-align: left;
  margin-bottom: 8px;
}

input,
textarea {
  width: 100%;
  padding: 12px;
  margin-bottom: 15px;
  border: 2px solid #b5b5b5;
  border-radius: 8px;
  font-size: 1rem;
  color: #333;
  background: #fffaf0;
  outline: none;
  transition: all 0.3s ease-in-out;
}

input:focus,
textarea:focus {
  border-color: #006400;
  background: #f0fff0;
}

textarea {
  resize: none;
  height: 100px;
}

button {
  padding: 12px 30px;
  font-size: 1.2rem;
  font-weight: bold;
  color: white;
  background: #daa520;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.3s ease-in-out;
}

button:hover {
  background: #b8860b;
  transform: translateY(-2px);
  box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
}

.result {
  margin-top: 30px;
  padding: 20px;
  background: #f0fff0;
  border: 1px solid #b5b5b5;
  border-radius: 10px;
  font-style: italic;
  color: #333;
  box-shadow: inset 0 2px 8px rgba(0, 0, 0, 0.1);
  white-space: pre-line;
}

.result h2 {
  color: #006400;
  font-size: 1.5rem;
  margin-bottom: 10px;
}

.gender-selection {
  margin: 15px 0;
  display: flex;
  justify-content: center; 
  gap: 20px; 
  align-items: center; 
}

.gender-selection label {
  font-size: 1rem;
  color: #4b4b4b;
  display: flex;
  align-items: center;
}

.gender-selection input {
  margin-right: 5px;
  accent-color: #006400; 
  cursor: pointer;
}


input::placeholder,
textarea::placeholder {
  color: #aaa;
  font-style: italic;
}
.forms{
    margin-right: 25px;
}
</style>

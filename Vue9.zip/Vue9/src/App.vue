<script setup>
import Genereator from './components/Genereator.vue';
</script>

<template>
  <div class="app">
    <Genereator />
  </div>
</template>


<style scoped>
/* .generator {
  font-family: Arial, sans-serif;
  max-width: 600px;
  margin: auto;
  text-align: center;
}
.form {
  margin-bottom: 20px;
}
label {
  display: block;
  margin-top: 10px;
}
input,
textarea {
  width: 100%;
  padding: 10px;
  margin-top: 5px;
  border: 1px solid #ccc;
  border-radius: 5px;
}
button {
  margin-top: 15px;
  padding: 10px 20px;
  background-color: #28a745;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}
button:hover {
  background-color: #218838;
}
.result {
  margin-top: 20px;
  font-style: italic;
  color: #555;
} */
</style>



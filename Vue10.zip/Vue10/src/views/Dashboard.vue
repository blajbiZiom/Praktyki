<template>
  <div class="dashboard">
    <div class="main-content">
      <div class="game-list-container">
        <GameList :steamId="steamId" />
      </div>
      <div class="stats-container">
         <div class="profile-container">
      <Profile :profile="profileData" />
        </div>
        <Stats :games="gameData" />
      </div>
    </div>
  </div>
</template>

<script>
import Profile from '@/components/Profile.vue';
import GameList from '@/components/GameList.vue';
import Stats from '@/components/Stats.vue';
import axios from 'axios';

export default {
  components: {
    Profile,
    GameList,
    Stats,
  },
  data() {
    return {
      profileData: null,
      gameData: [],
      steamID: '', 
    };
  },
  async mounted() {
    const apiKey = '6949B33AAF1813A9C27C53250D082428';

    this.steamID = this.$route.query.steamID || 'Brak ID';
    if (!this.steamID) {
      alert('Steam ID nie zostało przekazane.');

    const url = `http://localhost:8081/proxy/https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/`;


    try {
      const response = await axios.get(url, {
        params: {
          key: apiKey,
          steamids: steamId,
        },
      });

      
      const player = response.data.response.players[0];
      
     
      this.profileData = {
        name: player.personaname,
        avatarUrl: player.avatar,
      };

      
      const gamesResponse = await axios.get(
        `http://localhost:8081/proxy/http://api.steampowered.com/IPlayerService/GetOwnedGames/v0001/`,
        {
          params: {
            key: apiKey,
            steamid: steamId,
            include_appinfo: true,
            format: 'json',
          },
        }
      );
      this.gameData = gamesResponse.data.response.games || [];

    } catch (error) {
      console.error('Błąd podczas pobierania danych:', error);
    }}
  },
};
</script>

<style scoped>
.dashboard {
  display: flex;
  justify-content: flex-start; 
  align-items: flex-start;
  height: 100vh;
  padding: 20px;
  position: relative; 
}

.profile-container {
  top: 10px;
  right: 20px;
  text-align: center;
}

.profile-container img {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  margin-bottom: 10px;
}

.profile-container p {
  font-size: 1.2rem;
  font-weight: bold;
  color: #333;
}

.main-content {
  flex: 1;
  margin-left: 20px;
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
}

.game-list-container,
.stats-container {
  width: 48%; 
  padding: 20px;
  background-color: #f4f4f9;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  margin-bottom: 20px;
}

.game-list-container {
  background-color: #e7f5fe;
}

.stats-container {
  background-color: #f9e7e7;
}

h2 {
  margin-bottom: 15px;
  font-size: 1.5rem;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  font-size: 1rem;
  padding: 5px 0;
}
</style>

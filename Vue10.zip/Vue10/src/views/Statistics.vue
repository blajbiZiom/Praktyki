<template>
    <div class="stats">
      <h2>Statystyki Gier</h2>
      <div v-if="stats">
        <p>Łączny czas gry: <strong>{{ stats.totalPlaytime }}</strong> godzin</p>
        <p>Średni czas gry: <strong>{{ stats.averagePlaytime }}</strong> godzin</p>
        <p>
          Najczęściej grana gra:
          <strong>{{ stats.mostPlayed.name }}</strong> ({{ stats.mostPlayed.time }} godzin)
        </p>
      </div>
      <div v-else>
        <p>Ładowanie statystyk...</p>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    props: {
      games: {
        type: Array,
        required: true,
        default: () => [] 
      },
    },
    computed: {
      stats() {
        
        if (!this.games || this.games.length === 0) return null; // Zwracamy null, jeśli games jest puste lub nie istnieje
  
        const totalPlaytime = this.games.reduce((sum, game) => sum + game.playtime_forever, 0);
        const mostPlayed = this.games.reduce((max, game) =>
          game.playtime_forever > max.playtime_forever ? game : max
        );
  
        return {
          totalPlaytime: (totalPlaytime / 60).toFixed(1), // Łączny czas gry w godzinach
          averagePlaytime: ((totalPlaytime / this.games.length) / 60).toFixed(1), // Średni czas gry
          mostPlayed: {
            name: mostPlayed.name,
            time: (mostPlayed.playtime_forever / 60).toFixed(1), // Najczęściej grana gra
          },
        };
      },
    },
  };
  </script>
  
  <style scoped>
  .stats {
    max-width: 600px;
    margin: 2rem auto;
    padding: 1rem;
    background: #f9f9f9;
    border: 1px solid #ddd;
    border-radius: 5px;
  }
  .stats h2 {
    text-align: center;
  }
  .stats p {
    font-size: 1.2rem;
    margin: 0.5rem 0;
  }
  </style>
  
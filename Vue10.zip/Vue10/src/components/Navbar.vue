<template>
    <nav class="navbar">
      <h1>Steam Dashboard</h1>
      <ul>
        <li><router-link to="/dashboard">Dashboard</router-link></li>
        <li><router-link to="/Statistics">Statystyki (Nieaktywne)</router-link></li>
        <li><router-link to="/">Wyloguj</router-link></li>
      </ul>
    </nav>
  </template>
  
  <script>
  export default {
    name: 'Navbar',
  };
  </script>
  
  <style>
  .navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem;
    background-color: #222;
    color: #fff;
  }
  .navbar ul {
    list-style: none;
    display: flex;
    gap: 1rem;
  }
  .navbar a {
    color: #fff;
    text-decoration: none;
  }
  </style>
<template>
    <div>
      <h2>Profil gracza</h2>
      <p v-if="error">{{ error }}</p>
      <p v-if="profile">Nazwa: {{ profile.personaname }}</p>
      <p v-if="profile" class="avatar"> <img :src="profile.avatarfull"></p>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    props: {
    steamID: {
      type: String,
      required: true,
    }},
    data() {
      
      return {
        profile: null,
        error: null,
      };
    },
    async mounted() {
      const steamID = ''; 
      const apiKey = '6949B33AAF1813A9C27C53250D082428';
      const url = `http://localhost:8081/proxy/http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=${apiKey}&steamids=${steamID}`;
  
      try {
        const response = await axios.get(url);
        this.profile = response.data.response.players[0]; 
      } catch (error) {
        this.error = 'Nie udało się załadować profilu gracza.';
        console.error('Błąd podczas pobierania danych:', error);
      }
    },
  };
  </script>
  <style>
.avatar img{
    border-radius: 6px;
}
</style>
  
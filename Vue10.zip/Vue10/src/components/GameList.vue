<template>
    <div class="games">
      <h2>Twoje gry</h2>
      <ul v-if="games.length">
        <li v-for="game in games" :key="game.appid">
          {{ game.name }} - {{ (game.playtime_forever / 60).toFixed(1) }} godzin
        </li>
      </ul>
      <p v-else>Brak gier do wyświetlenia.</p>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    props: ['steamId'],
    data() {
      return {
        games: [],
      };
    },
    async mounted() {
      const apiKey = '6949B33AAF1813A9C27C53250D082428';
  
      if (!this.steamId) {
        console.error('Brak steamId');
        return;
      }
  
      try {
        const response = await axios.get(
          `http://localhost:8081/http://api.steampowered.com/IPlayerService/GetOwnedGames/v0001/`,
          {
            params: {
              key: apiKey,
              steamid: this.steamId,
              include_appinfo: true,
              format: 'json',
            },
          }
        );
  
        this.games = response.data.response.games || [];
        console.log(this.games);
      } catch (error) {
        console.error('Błąd podczas pobierania gier:', error);
      }
    },
  };
  </script>
  
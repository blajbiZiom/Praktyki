module.exports = {
    devServer: {
      proxy: {
        '/proxy': {
          target: 'https://api.steampowered.com', 
          changeOrigin: true, 
          pathRewrite: { '^/proxy': '' }, 
          secure: false, 
        },
      },
    },
  };
  
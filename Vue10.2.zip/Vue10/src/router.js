
import { createRouter, createWebHistory } from 'vue-router';
import Login from '@/views/Login.vue';
import Dashboard from '@/views/Dashboard.vue';
import Statistics from '@/components/Statistics.vue';  
import NotFound from '@/views/NotFound.vue';
import Stat from './views/Stat.vue';

const routes = [
  { path: '/login', component: Login },
  /* { path: '/dashboard', component: Dashboard }, */
  { path: '/stat', component: Stat,
    props: (route) => ({ steamID: route.query.steamID })
   },  
  { path: '/:pathMatch(.*)*', component: NotFound },
  {path: '/dashboard',
    component: Dashboard,
    props: (route) => ({ steamID: route.query.steamID })},
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;

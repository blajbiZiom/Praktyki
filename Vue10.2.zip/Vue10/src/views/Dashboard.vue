<template> 
  <div class="dashboard">
    <div class="main-content">
      <div class="game-list-container">
        <GameList :steamID="steamID" />
      </div>
      <div class="stats-container">
        <div class="profile-container">
          <Profile :steamID="steamID" />
        </div>
        <Stats :games="gameData" />  
      </div>
    </div>
  </div>
</template>

<script>
// PROXY PORT 8081/axios NEEDED
import Profile from '@/components/Profile.vue';
import GameList from '@/components/GameList.vue';
import Stats from '@/components/Stats.vue';
import axios from 'axios';


export default {
  props: {
    steamID: {
      type: String,
      required: true, 
    },
  },
  components: {
    Profile,
    GameList,
    Stats,
  },
  data() {
    return {
      gameData: [],
      steamID: this.$route.query.steamID || '',
    };
  },
  async created() {
    if (!this.steamID) {
      alert('Steam ID nie zostało przekazane. Powrót do logowania.');
      this.$router.push('/login'); 
      return;
    }

    
    await this.fetchGameData();
  },
  methods: {
    async fetchGameData() {
      const apiKey = '6949B33AAF1813A9C27C53250D082428'; 
      try {
        const response = await axios.get(
          `http://localhost:8081/proxy/https://api.steampowered.com/IPlayerService/GetOwnedGames/v0001/`,
          {
            params: {
              key: apiKey,
              steamid: this.steamID,
              include_appinfo: true,
              format: 'json',
            },
          }
        );
        this.gameData = response.data.response.games || [];
      } catch (error) {
        console.error('Błąd podczas pobierania listy gier:', error);
      }
    },
  },
};
</script>

<style scoped>
.dashboard {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 2rem;
}

.main-content {
  display: flex;
  gap: 2rem;
  width: 100%;
  max-width: 1200px;
}

.game-list-container,
.stats-container {
  flex: 1;
  background-color: var(--card-bg-color);
  border-radius: var(--border-radius);
  box-shadow: var(--shadow);
  padding: 1.5rem;
}

.profile-container {
  text-align: center;
}

.profile-container img {
  width: 100px;
  height: 100px;
  border-radius: 50%;
  border: 3px solid var(--primary-color);
  margin-bottom: 1rem;
}

</style>

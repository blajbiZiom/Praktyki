<template>
    <div class="not-found">
      <h1>404 - Nie znaleziono strony</h1>
      <p>Przepraszamy, ale strona, której szukasz, nie istnieje.</p>
      <router-link to="/">Wróć do strony głównej</router-link>
    </div>
  </template>
  
  <script>
  export default {
    name: 'NotFound',
  };
  </script>
  
  <style>
  .not-found {
    text-align: center;
    margin-top: 5rem;
  }
  .not-found a {
    color: #007bff;
    text-decoration: none;
  }
  </style>
  
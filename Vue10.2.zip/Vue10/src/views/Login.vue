<template>
  <div class="login">
    <h1>Steam dashboard</h1>
    <input type="text" v-model="steamID" placeholder="Wpisz Steam ID" />
    <button @click="goToDashboard">Zaloguj</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      steamID: "", 
    };
  },
  methods: {
    goToDashboard() {
      if (this.steamID) {
        localStorage.setItem('steamID', this.steamID);
        this.$router.push({ path: '/dashboard', query: { steamID: this.steamID } });
      } else {
        alert("Wpisz steam ID"); 
      }
    },
  },
};
</script>
<style>
.login {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 84vh;
  background-color: var(--card-bg-color);
  border-radius: var(--border-radius);
  box-shadow: var(--shadow);
  padding: 2rem;
  max-width: 400px;
  margin: 0 auto;
  margin-top: 1vh;
  margin-bottom: 1vh;
}

.login h1 {
  margin-bottom: 1.5rem;
}

.login input {
  padding: 0.8rem;
  margin-bottom: 1rem;
  width: 100%;
  border: 1px solid #ddd;
  border-radius: var(--border-radius);
  font-size: 1rem;
}

.login button {
  width: 100%;
}</style>

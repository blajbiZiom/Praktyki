<template>
  <div>
    <Statistics :steamID="steamID" />
  </div>
</template>

<script>
import Statistics from '../components/Statistics.vue';

export default {
  components: { Statistics },
  data() {
    return {
      steamID: null, 
    };
  },
  created() {
   
    this.steamID = localStorage.getItem('steamID');

    if (!this.steamID) {
      alert('Brak SteamID. Wróć do logowania.');
      this.$router.push('/login');
    }
  },
};
</script>
<style>
.game-list-container {
  background-color: #e7f5fe;
}

.stats-container {
  background-color: #fef7e7;
}

.game-list-container h2,
.stats-container h2 {
  margin-bottom: 1rem;
  font-size: 1.4rem;
}

.game-item {
  font-size: 1rem;
  margin: 5px 0;
  padding: 8px;
  border-bottom: 1px solid #ddd;
}

.game-item:last-child {
  border-bottom: none;
}

.game-item:hover {
  background-color: #f1f1f1;
  transition: background-color 0.3s;
}</style>

<template>
  <div v-if="profileData">
      <img :src="profileData.avatarfull" alt="Avatar" class="avatar" />
      <h2>{{ profileData.personaname }}</h2>
    </div>
</template>
<script>
import axios from 'axios';

export default {
  props: {
    steamID: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      profileData: null,
      error: null,
    };
  },
  async mounted() {
    const apiKey = '6949B33AAF1813A9C27C53250D082428';
    try {
      const response = await axios.get(
        `http://localhost:8081/proxy/https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/`,
        { params: { key: apiKey, steamids: this.steamID } }
      );
      this.profileData = response.data.response.players[0];
    } catch (error) {
      this.error = 'Błąd podczas pobierania profilu.';
    }
  },
};
</script>
<style>
img{
  border-radius: 7px;
}
</style>
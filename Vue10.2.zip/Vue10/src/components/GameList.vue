<template>
  <div class="games">
    <h2>Twoje gry</h2>
 
    <div v-if="isLoading" class="loading">
      Ładowanie listy gier...
    </div>

   
    <ul v-else-if="games.length" class="game-list">
      <li v-for="game in games" :key="game.appid" class="game-item">
        <strong>{{ game.name }}</strong> - {{ formatPlaytime(game.playtime_forever) }} godzin
      </li>
    </ul>


    <p v-else class="no-games">Brak gier do wyświetlenia.</p>

    
    <p v-if="error" class="error">{{ error }}</p>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  props: {
    steamID: {
      type: String,
      required: true, 
    },
  },
  data() {
    return {
      games: [], 
      isLoading: true, 
      error: null, 
    };
  },
  methods: {
    
    formatPlaytime(playtime) {
      return (playtime / 60).toFixed(1); 
    },
    
    async fetchGames() {
  const apiKey = '6949B33AAF1813A9C27C53250D082428'; 
  const url = `http://localhost:8081/proxy/https://api.steampowered.com/IPlayerService/GetOwnedGames/v0001/`;

  try {
    const response = await axios.get(url, {
      params: {
        key: apiKey,
        steamid: this.steamID,
        include_appinfo: true,
        format: 'json',
      },
    });

    
    this.games = (response.data.response.games || []).sort((a, b) => b.playtime_forever - a.playtime_forever);

    console.log('Pobrane gry:', this.games);
  } catch (error) {
    console.error('Błąd podczas pobierania gier:', error);
    this.error = 'Nie udało się pobrać listy gier. Spróbuj ponownie później.';
  } finally {
    this.isLoading = false; 
  }
},

  },
  async mounted() {
    if (!this.steamID) {
      this.error = 'Nie przekazano SteamID.';
      this.isLoading = false;
      return;
    }
    await this.fetchGames();
  },
};
</script>

<style scoped>
.game-list-container {
  background-color: #e7f5fe;
}

.stats-container {
  background-color: #fef7e7;
}

.game-list-container h2,
.stats-container h2 {
  margin-bottom: 1rem;
  font-size: 1.4rem;
}

.game-item {
  font-size: 1rem;
  margin: 5px 0;
  padding: 8px;
  border-bottom: 1px solid #ddd;
}

.game-item:last-child {
  border-bottom: none;
}

.game-item:hover {
  background-color: #f1f1f1;
  transition: background-color 0.3s;
}
</style>

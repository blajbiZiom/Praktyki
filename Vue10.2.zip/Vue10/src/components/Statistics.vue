<template>
  <div class="statistics">
    <h2>Statystyki Steam</h2>
    <ul v-if="stats">
      <li>Najdłuższa sesja gry: {{ longestSession }} minut</li>
      <li>Średnia ilość gier na miesiąc: {{ averageGamesPerMonth }}</li>
      <li>Liczba posiadanych gier: {{ totalGames }}</li>
    </ul>
    <p v-else>Ładowanie danych...</p>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  props: {
    steamID: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      stats: null,
    };
  },
  async mounted() {
    const steamId = this.steamID;
    console.log('Wysyłany steamID:', steamId);  
    const apiKey = '6949B33AAF1813A9C27C53250D082428';

    try {
      const response = await axios.get(
        `http://localhost:8081/proxy/https://api.steampowered.com/IPlayerService/GetOwnedGames/v0001/`,
        {
          params: {
            key: apiKey,
            steamid: steamId,
            include_appinfo: true,
            format: 'json',
          },
        }
      );

      console.log(response.data); 

      const games = response.data.response.games || [];
      
      if (games.length) {
        const totalPlaytime = games.reduce((acc, game) => acc + game.playtime_forever, 0);
        const longestSession = Math.max(...games.map(game => game.playtime_forever));
        const averageGamesPerMonth = (games.length / 12).toFixed(1); 
        const totalGames = games.length;

        this.stats = {
          totalPlaytime: (totalPlaytime / 60).toFixed(1),
          longestSession: (longestSession / 60).toFixed(1),
          averageGamesPerMonth,
          totalGames,
        };
      }
    } catch (error) {
      console.error('Błąd podczas ładowania statystyk:', error);
    }
  },
  computed: {
    longestSession() {
      return this.stats ? this.stats.longestSession : 'Brak danych';
    },
    averageGamesPerMonth() {
      return this.stats ? this.stats.averageGamesPerMonth : 'Brak danych';
    },
    totalGames() {
      return this.stats ? this.stats.totalGames : 0;
    },
  },
};
</script>

<style >
.statistics {
  padding: 20px;
  background-color: #f9f7f7;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

h2 {
  font-size: 1.5rem;
  margin-bottom: 15px;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  font-size: 1.2rem;
  margin-bottom: 10px;
}
</style>

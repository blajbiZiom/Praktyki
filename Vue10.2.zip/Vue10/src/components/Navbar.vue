<template>
    <nav class="navbar">
      <h1>Steam Dashboard</h1>
      <ul>
        <li><router-link to="/login">SteamID</router-link></li>
        <li><router-link to="/dashboard">Dashboard</router-link></li>
        <li><router-link to="/stat">Statystyki</router-link></li>
        <li id="logout"><a @click="logout">Wyloguj</a> </li>
      </ul>
    </nav>
  </template>
  
  <script>
  export default {
    name: 'Navbar',
    methods: {
    logout() {
      localStorage.removeItem('steamID');
      
      this.$router.push('/login');
    },
  },
};
 
  </script>
  
  <style>
  .navbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 2rem;
  background-color: var(--primary-color);
  color: #fff;
  box-shadow: var(--shadow);
}

.navbar h1 {
  font-size: 1.5rem;
  margin: 0;
}

.navbar ul {
  list-style: none;
  display: flex;
  gap: 1.5rem;
  margin: 0;
}

.navbar a {
  color: #fff;
  font-weight: bold;
  transition: color 0.3s, transform 0.3s;
}

.navbar a:hover {
  color: #ddd;
  transform: scale(1.05);
}

#logout {
  cursor: pointer;
  color: #fff;
}

#logout:hover {
  color: #ddd;
  transform: scale(1.05);
}

  </style>
<script>
export default {
  data() {
    return {
      inc: 0,
      additionalInc: 0,
      totalBudget: 0,
      currency: ' zł',
      out: 0,
      outList: [],
      categories: [],
      customCategory: "",
      budgetStatus: true 
    };
  },
  methods: {
    income() {
      const sum = parseFloat(this.inc) + parseFloat(this.additionalInc);
      if (!isNaN(sum)) {
        this.totalBudget += sum;
        this.inc = 0;
        this.additionalInc = 0;
        this.currency = ' zł';
        if (this.totalBudget > 0) {
          this.budgetStatus = true; 
        }
      }
    },
    outcome() {
      const dev = parseFloat(this.out);
      if (!isNaN(dev)) {
        this.totalBudget -= dev;
        const selectedCategories = this.categories.length
          ? this.categories.join(", ")
          : this.customCategory || "Brak kategorii";
        const outMessage = `Wydałeś właśnie ${dev} zł. Kategoria: ${selectedCategories}`;
        this.outList.push(outMessage);
        this.out = 0;
        this.categories = [];
        this.customCategory = "";

        if (this.totalBudget < 0) {
          this.budgetStatus = false;
          this.currency = ''; 
        }
      }
    }
  }
};
</script>

<template>
  <div class="app">
    <h1>Menedżer wydatków</h1>
    <div class="forms">
      <div class="income">
        <h2 id="budget">Budżet: 
          <span v-if="budgetStatus">{{ totalBudget }} {{ currency }}</span>
          <span v-else>Nie masz hajsu! Jesteś na minusie, więc doładuj konto</span>
        </h2>
        <form @submit.prevent="income">
          <h2>Przychody</h2>
          <hr>
          Dochód podstawowy:
          <input min="0" v-model.number="inc" type="number" placeholder="Podaj kwotę dochodu: "> 
          Dochód dodatkowy:
          <input min="0" v-model.number="additionalInc" type="number" placeholder="Dodatkowy przychód (jak nie ma to 0)">
          <button type="submit">Zatwierdź</button>
        </form>
      </div>

      <div class="outcome">
        <h2>Wydatki</h2>
        <form @submit.prevent="outcome">
          <input min="0" v-model.number="out" type="number" placeholder="Podaj kwotę wydanych pieniędzy: ">
          <button type="submit">Zatwierdź</button>
          <h3>Kategorie: </h3>
          <label><input type="checkbox" value="Wydatki podstawowe" v-model="categories"> Wydatki podstawowe</label><br>
          <label><input type="checkbox" value="Rozrywka" v-model="categories"> Rozrywka</label><br>
          <label><input type="checkbox" value="Elektronika" v-model="categories"> Elektronika</label><br>
          <label><input type="checkbox" value="Transport" v-model="categories"> Transport</label><br>
          <label><input type="checkbox" value="Oszczędności" v-model="categories"> Oszczędności</label><br>
          <label>Własna kategoria: <input v-model="customCategory" type="text" placeholder="Własna kategoria"></label>
        </form>
      </div>

      <div class="list">
        <h2>Historia wydatków</h2>
        <div v-for="(outMessage, index) in outList" :key="index">
          {{ outMessage }}
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>

.app {
  max-width: 600px;
  margin: 50px auto;
  padding: 20px;
  background-color: #f7f9fc;
  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
  border-radius: 10px;
  font-family: 'Arial', sans-serif;
}
#budget{
  font-size:x-large;
  font-weight: 800;
}

h1{
font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
}

h2 {
  font-size: 24px;
  color: #333;
  margin-bottom: 10px;
  text-align: center;
  font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
}

h3{
  font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
}

.income,
.outcome {
  margin-bottom: 30px;
  padding: 20px;
  background-color: #ffffff;
  border-radius: 10px;
  box-shadow: 0px 2px 6px rgba(0, 0, 0, 0.1);
}

input[type="number"],
input[type="text"] {
  width: calc(100% - 10px);
  padding: 10px;
  margin: 10px 0;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 16px;
  box-sizing: border-box;
}

button {
  width: 100%;
  padding: 10px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
  font-size: 18px;
  cursor: pointer;
  transition: background-color 0.3s;
}

button:hover {
  background-color: #0056b3;
}

label {
  display: block;
  font-size: 16px;
  margin: 8px 0;
}

input[type="checkbox"] {
  margin-right: 10px;
}

.list {
  padding: 20px;
  background-color: #ffffff;
  border-radius: 10px;
  box-shadow: 0px 2px 6px rgba(0, 0, 0, 0.1);
}

.list h2 {
  text-align: center;
  font-size: 22px;
}

.list div {
  font-size: 16px;
  padding: 10px 0;
  border-bottom: 1px solid #eee;
}

.list div:last-child {
  border-bottom: none;
}


span {
  font-weight: bold;
}

span:not(.budget) {
  color: #ff0000;
  font-size: 18px;
}


@media (max-width: 768px) {
  .app {
    width: 90%;
    padding: 15px;
  }

  input[type="number"],
  input[type="text"] {
    font-size: 14px;
  }

  button {
    font-size: 16px;
  }

}
</style>


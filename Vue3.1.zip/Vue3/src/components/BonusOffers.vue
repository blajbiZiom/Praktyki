<template>
    <div class="bonus-offers">
      <h1>Oferty Bukmacherskie</h1>
      <div v-if="loading" class="loading">Ładowanie...</div>
      <div v-if="error" class="error">{{ error }}</div>
      <div v-if="bonusOffers.length > 0">
        <div class="offer-card" v-for="offer in bonusOffers" :key="offer.name">
          <h2>{{ offer.title }}</h2>
          <img :src="offer.image" alt="Logo {{ offer.title }}" class="offer-image" />
          <p>Kod promocyjny: <strong>{{ offer.code }}</strong></p>
          <p>
            <a :href="offer.link"
               target="_blank" class="offer-link">Zobacz ofertę</a>
          </p>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        loading: true,
        error: null,
        bonusOffers: []
      };
    },
    async mounted() {
      await this.fetchBonusOffers();
    },
    methods: {
      async fetchBonusOffers() {
        console.time('Pobieranie danych');
        try {
          const response = await axios.get('https://pewniaczki.pl/wp-json/api/bonus');
          console.timeEnd('Pobieranie danych');
          console.log('Odpowiedź z API:', response.data);
  
          if (response.data && Array.isArray(response.data.bonuses)) {
            this.bonusOffers = response.data.bonuses.map(offer => {
              const link = offer.name ? `https://pewniaczki.pl/bonus/${offer.name}` : null;
              return { ...offer, link };
            });
            console.log('Przetworzone oferty:', this.bonusOffers);
          } else {
            this.bonusOffers = [];
            this.error = 'Brak ofert do wyświetlenia.';
          }
        } catch (err) {
          this.error = 'Nie udało się pobrać danych.';
          console.error('Błąd:', err);
        } finally {
          this.loading = false;
        }
      }
    }
  };
  </script>
  
  <style scoped>

  .loading {
    font-size: 1.2em;
    color: #555;
  }
  
  .error {
    color: red;
    font-weight: bold;
  }
  
  .offer-card {
    border: 1px solid #ddd;
    border-radius: 5px;
    padding: 15px;
    margin-bottom: 15px;
  }
  
  .offer-image {
    max-width: 150px;
    height: auto;
    margin-bottom: 10px;
  }
  
  .offer-link {
    color: blue;
    text-decoration: underline;
    cursor: pointer;
  }
  
  .offer-link:hover {
    color: darkblue;
  }
  </style>
  
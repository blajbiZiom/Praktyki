<script setup>
import { ref } from 'vue';
import MyForm from './components/MyForm.vue';

const bgColor = ref('white'); 


const changeColour = (color) => {
  if (bgColor.value === 'white') {
    bgColor.value = 'black';
    document.body.style.backgroundColor = 'black'; 
    document.body.style.color = "white";
  } else {
    bgColor.value = 'white';
    document.body.style.backgroundColor = 'white'; 
    document.body.style.color = "black";
  }
};

</script>

<template>
  
  <div :style="{ backgroundColor: bgColor }">
    <MyForm :changeColour="changeColour" />
  </div>
</template>

<style scoped>

</style>

<template>
    <div id="main">
    <h1>Losowe imie - generator</h1>
      <p>Dodaj imiona: {{ name }}</p>
      <input type="text" placeholder="Name" v-model="name">
      <div>
        <button @click="submitForm">Submit</button>
        
        <button @click="changeColour('black')">Change Colour</button>
        <button @click="clearList">Clear</button>
      </div>
      <div>
        <button id="pick" @click="generateName">Pick a random name</button>
        <p>Lista osób: </p>
        <ul>
          <li v-for="(item, index) in items" :key="index">
            {{ item }}
          </li>
        </ul>
        <p v-if="randName" id="randName">Wybrane imie to: {{ randName }} </p>
      </div>
    </div>
  </template>
  
  <script>
  import { ref } from 'vue';
  
  export default {
    props: {
      
      changeColour: Function,
    },
    setup() {
      const name = ref('');
      const items = ref([]);
      const randName = ref(null)
  
      const submitForm = () => {
        if (name.value.trim() !== '') {
          items.value.push(name.value);
          name.value = '';
        }
      };
  
      const clearList = () => {
        items.value = [];
        randName.value = null;
      };

      const generateName = () => {
       if(items.value.length > 0){
       const randIndex =  Math.floor(Math.random() * items.value.length)
        randName.value = items.value[randIndex];
       } else {
        randName.value = null;
       }

      };
  
      return {
        name,
        items,
        randName,
        submitForm,
        clearList,
        generateName,
      };
    },
  };
  </script>
  
  <style>
  input[type='text'] {
    padding: 5px;
    border-radius: 10px;
    border-color: red;
    transition: background-color 0.5s ease;
  }
  
  input[type='text']:hover {
    background-color: gainsboro;
  }
  
  button {
    padding: 20px;
    border-radius: 100px;
    margin-top: 20px;
    border-color: crimson;
    background-color: white;
    transition: background-color 0.5s ease;
    margin-left: 5px;
    margin-right: 5px;
  }
  
  button:hover {
    border-color: red;
    background-color: gainsboro;
  }
  
  li {
    list-style-type: none;
  }
  
  ul {
    margin-right: 35px;
  }
  h1{
    padding: 10px;
    color: crimson;
  }
  #main{
    margin-bottom: 275px;
  }
#randName{
    color:brown;
    font-weight: bold;
    text-transform: capitalize;
    font-size: large;
}
#pick{
    margin-left: 18px;
}
  </style>
  
<template>
    <div class="background">
      <div class="snowflake" v-for="n in 50" :key="n"></div>
    </div>
  </template>
  
  <script>
  export default {
    name: 'Background',
  };
  </script>
  
  <style scoped>
  .background {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(to bottom, #b3d4fc, #ffffff); 
    overflow: hidden;
    z-index: -1; 
  }
  
  .snowflake {
    position: absolute;
    top: -10px;
    width: 10px;
    height: 10px;
    background: white;
    border-radius: 50%;
    opacity: 0.8;
    animation: fall linear infinite;
  }
  
  
  .snowflake:nth-child(odd) {
    width: 8px;
    height: 8px;
    animation-duration: 8s;
    animation-delay: calc(-1s * var(--i));
  }
  
  .snowflake:nth-child(even) {
    width: 12px;
    height: 12px;
    animation-duration: 10s;
    animation-delay: calc(-1.5s * var(--i));
  }
  
  @keyframes fall {
    0% {
      transform: translateY(-50px) translateX(0);
    }
    100% {
      transform: translateY(100vh) translateX(calc(-20px + 40px * var(--i)));
    }
  }
  
  
  .snowflake {
    --i: calc(var(--index, 1) * 0.2);
    left: calc(100% * var(--i));
  }
  </style>
  
<template>
    <div class="countdown">
        <h1>Świąteczne odliczanie!</h1>
        <div class="timer">
            <span>{{ timeLeft.days }} dni</span>
            <span>{{ timeLeft.hours }} godzin</span>
            <span>{{ timeLeft.minutes }} minut</span>
            <span>{{ timeLeft.seconds }} sekund</span>
        </div>
    </div>
</template>
<script>
import {ref, computed, onMounted} from 'vue'

export default{
    setup(){
        const targetDate = new Date('2024-12-24T00:00:00'); 
        const timeLeft = ref({ days: 0, hours: 0, minutes: 0, seconds: 0 });

        const calculateTimeLeft = () =>{
            const now = new Date();
            const difference = targetDate - now;

            if (difference > 0) {
        timeLeft.value = {
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / (1000 * 60)) % 60),
          seconds: Math.floor((difference / 1000) % 60),
        };
      } else {
        timeLeft.value = { days: 0, hours: 0, minutes: 0, seconds: 0 };
      }
      
        }
        onMounted(() => {
      calculateTimeLeft();
      setInterval(calculateTimeLeft, 1000);
    });

    return { timeLeft };
    }
}

</script>
<style>
.countdown {
  text-align: center;
  font-family: 'Arial', sans-serif;
}
.timer {
  font-size: 2rem;
  display: flex;
  justify-content: center;
  gap: 1rem;
}
h1{
    font-size:50px ;
    transition: 0.5s;
}
h1:hover{

font-size: 75px;
}
</style>
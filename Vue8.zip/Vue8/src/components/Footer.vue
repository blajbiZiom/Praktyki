<template>
    <div class="footer">
        <p>{{ currentQuote }}</p>
    </div>
</template>
<script>
export default{
    data(){
        return{
            quotes: ['W Boże Narodzenie wszystkie drogi prowadzą do domu','Najlepszymi prezentami świątecznymi są prezenty miłości i czasu', 'Najlepszy ze wszystkich prezentów wokół choinki: obecność szczęśliwej rodziny, która jest w sobie zakochana', 'Celem Świąt Bożego Narodzenia jest nie tyle otwieranie prezentów, co otwieranie serc', 'Białe opłatki, białe stoły, Świeżych choinek las… Doprawdy mogą dziś anioły Zagościć pośród nas', 'Życie bez marzeń jest jak Święta bez przyjaciół.'],
            currentQuote: '',
            currentIndex: 0,
        };
    },
    methods: {
    updateQuote() {
      
      this.currentIndex = (this.currentIndex + 1) % this.quotes.length;
      this.currentQuote = this.quotes[this.currentIndex];
    },
  },
  mounted() {

    this.currentQuote = this.quotes[0];
    
    setInterval(this.updateQuote, 5000);
  },
}
</script>
<style>
.footer {
  text-align: center;
  font-size: 1.2rem;
  color: #555;
  margin-top: 20px;
}
</style>
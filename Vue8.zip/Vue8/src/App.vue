<script>
import countDownTimer from './components/countDownTimer.vue';
import Footer from './components/Footer.vue';
import Background from './components/Background.vue';

export default {
  components: {
    countDownTimer,
    Background,
    Footer,
  },
};  
</script>

<template>
 <div id="app">
    <Background />
    <countDownTimer />
    <Footer />
  </div>
</template>

<style scoped>

</style>
